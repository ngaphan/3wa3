<?php

// model/productModel.class.php

/**
 * Classe permettant de gérer les produits
 */
class ProductModel extends Model
{
  protected $table = 'products';
  protected $tableIdColumn = 'productId';

  public function listAll($categoryId = null)
  {
    if (!is_null($categoryId))
    {
      $whereArray = [
        'categoryId' => $categoryId
      ];

      return $this->SQLQueryManager->select($this->table, $whereArray);
    }
    else
    {
      $query = "SELECT *
                FROM products AS p, categories AS c
                WHERE p.categoryId = c.categoryId
                ORDER BY c.categoryName, p.productName";

      // On demande l'exécution de la requête SQL
      // ainsi que la récupération des résultats (listes de produits du panier)
      // sous la formes d'un tableau à deux dimensions
      return $this->SQLQueryManager->query($query, [], true);
    }
  }

  public function add()
  {
    $valuesArray = [
      'productName' => $_POST['productName'],
      'productDescription' => $_POST['productDescription'],
      'productPrice' => $_POST['productPrice'],
      'categoryId' => $_POST['categoryId']
    ];

    $products = $this->SQLQueryManager->insert($this->table, $valuesArray);
  }
}
