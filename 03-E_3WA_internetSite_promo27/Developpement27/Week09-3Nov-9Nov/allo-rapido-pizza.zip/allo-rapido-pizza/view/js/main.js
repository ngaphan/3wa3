$(function() {

  $('#productAddButton').click(
    function()
    {
      $('#formProductAdd').toggleClass('hidden');
    }
  );

  $('#categoryAddButton').click(
    function()
    {
      $('#formCategoryAdd').toggleClass('hidden');
    }
  );

});