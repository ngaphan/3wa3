$(function(){
	/*
	$('.btn').on('click',function(){
		$(this).css('background','#000');

	})
*/
$('.modal-box').on('click','.btn',function(e){
	e.preventDefault();
	$(this).css("background","#000");
		//console.log('target,e.target');
		//console.log('currentTarget',e.currentTarget);

	});
$('.modal').on('click',function(e){
	/*alert(typeof(e));*/
	$(this).fadeOut();

})
$('.modal-box').click(function(e){
	e.stopPropagation();
})


	$('.modal-box').append('<a href="#" class="btn">Ajout bouton</a>');
});