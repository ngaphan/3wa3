﻿$(document).ready(function() {


   $("#masque").hide();

   $("a#afficher").click(function() {

   

      $("#masque").show("fast");

  	  return false;
	

   });

  

});
