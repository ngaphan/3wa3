﻿$(document).ready(function() {


   $("#masque").show();

   $("a#masquer").click(function() {

   

      $("#masque").hide("fast");

  	  return false;
	

   });

  

});