* LIENS / RESSOURCES *

* [Boiler Plate](http://html5boilerplate.com)
* [Normalize.css](http://necolas.github.io/normalize.css/)
* [Clearfix](http://nicolasgallagher.com/micro-clearfix-hack/)
* [ModernizR](http://modernizr.com)
* [PrefixR](http://prefixr.com)
* [Can I use ?](http://caniuse.com)
* [Box Shadow](http://www.css3.info/preview/box-shadow/)
* [Flexslider](http://www.woothemes.com/flexslider/)


[Aurélien](mailto:aurelien@aastudio.fr)

