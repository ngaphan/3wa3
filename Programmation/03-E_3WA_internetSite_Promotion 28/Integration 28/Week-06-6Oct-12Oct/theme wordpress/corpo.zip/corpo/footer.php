        </div><!-- END #content-wrapper -->
        <footer id="footer">
            <div id="footer-inner" class="row">
                <?php if( is_active_sidebar('prefooter-sidebar') ) : ?>
                <?php endif; ?>
            </div>
        </footer><!-- END #footer -->
        <div id="footer-bar">
            <div class="right">
                <div id="footer-nav">
                <?php
                    if(has_nav_menu('footer-menu')){
                         wp_nav_menu(array(
                            'theme_location'  => 'footer-menu',
                            'container'       => false, 
                            'menu_class'      => 'menu', 
                            'menu_id'         => 'footer-menu',
                            'echo'            => true,
                            'depth'           => 1,
                         ));
                    }
                ?>
                </div>
            </div>
            <div class="left">
               Giusmili Copyright &copy; <?php echo date("Y"); ?> 
            </div>
        </div>
    </div><!-- END #wrapper -->

    <?php wp_footer(); ?>
	</body>
</html>