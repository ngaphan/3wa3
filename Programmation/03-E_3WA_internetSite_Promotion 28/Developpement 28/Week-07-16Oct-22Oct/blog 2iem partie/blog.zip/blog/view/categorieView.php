<div class="row">
  <h3>Vous êtes dans la catégorie : <?= $categorieName; ?></h3>
  <?php foreach($categorieArticles as $article) : ?>
    <div class="col-lg-4">
      <img class="img-circle" src="<?= $article['image']; ?>" alt="Generic placeholder image" style="width: 140px; height: 140px;">
      <h2><?= $article['titre']; ?></h2>
      <p><?= getLittleDescription($article['description']); ?></p>
      <p><a class="btn btn-default" href="?page=article&id=<?= $article['id']; ?>" role="button">View details »</a></p>
    </div><!-- /.col-lg-4 -->
  <?php endforeach; ?>
</div>