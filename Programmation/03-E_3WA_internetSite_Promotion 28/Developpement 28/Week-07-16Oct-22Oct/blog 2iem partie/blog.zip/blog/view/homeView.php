<h1 class="page-header">
    Mon blog
</h1>


<?php foreach($articles as $article) : ?>
    <!-- First Blog Post -->
    <h2>
        <a href="?page=article&id=<?= $article['id'] ?>"><?= $article['titre'] ?></a>
    </h2>
    <p class="lead">
        by <span><?= $article['auteur'] ?></span>
    </p>
    <p class="lead">
        category <a href="?page=categorie&id=<?= $article['idcat'] ?>"><?= $article['nom'] ?></a>
    </p>
    <p><span class="glyphicon glyphicon-time"></span> Posted on <?= $article['date_article'] ?></p>
    <hr>
    <img class="img-responsive" src="<?= $article['image'] ?>" alt="">
    <hr>
    <p><?= getLittleDescription($article['contenu']) ?></p>
    <a class="btn btn-primary" href="?page=article&id=<?= $article['id'] ?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

    <hr>
<?php endforeach; ?>

<!-- Pager -->
<ul class="pager">
    <li class="previous">
        <a href="#">&larr; Older</a>
    </li>
    <li class="next">
        <a href="#">Newer &rarr;</a>
    </li>
</ul>