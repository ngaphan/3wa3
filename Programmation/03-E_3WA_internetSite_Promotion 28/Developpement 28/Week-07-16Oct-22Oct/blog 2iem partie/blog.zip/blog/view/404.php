<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Blog</title>
</head>
<body>
	<h1>Page 404</h1>
</body>
</html>