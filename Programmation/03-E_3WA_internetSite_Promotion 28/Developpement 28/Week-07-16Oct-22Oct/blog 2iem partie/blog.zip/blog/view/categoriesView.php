<div class="jumbotron">
    <h1>Les catégories</h1>
    <p>Listing des catégories</p>
</div>

<div class="row">
    <?php foreach($categories as $categorie) : ?>
        <div class="col-6 col-sm-6 col-lg-4">
          <h2><?= $categorie['nom'] ?></h2>
          <p><?= getLittleDescription($categorie['description']) ?></p>
          <p><a class="btn btn-default" href="?page=categorie&id=<?= $categorie['id'] ?>" role="button">View details »</a></p>
        </div>
    <?php endforeach; ?>
</div>