<h1><?= $article['titre'] ?></h1>

<!-- Author -->
<p class="lead">
    by <a href="#"><?= $article['auteur'] ?></a>
</p>

<hr>

<!-- Date/Time -->
<p><span class="glyphicon glyphicon-time"></span> Posted on <?= $article['date_article'] ?></p>

<hr>

<!-- Preview Image -->
<img class="img-responsive" src="<?= $article['image'] ?>" alt="">

<hr>

<!-- Post Content -->
<p class="lead"><?= $article['contenu'] ?></p>

<hr>

<!-- Blog Comments -->

<!-- Comments Form -->
<div class="well">
    <h4>Leave a Comment:</h4>
    <form role="form" method="POST">
        <div class="form-group">
            <input type="text" class="form-control" name="auteur" placeholder="auteur">
        </div>
        <div class="form-group">
            <input type="number" class="form-control" name="note" placeholder="note" value="0">
        </div>
        <div class="form-group">
            <textarea name="contenu" class="form-control" rows="3" placeholder="commentaire"></textarea>
        </div>
        <button type="submit" name="add_commentaire" class="btn btn-primary">Submit</button>
    </form>
</div>

<hr>

<!-- Posted Comments -->

<!-- Comment -->


<?php foreach($commentaires as $com) : ?>
<div class="media">
    <a class="pull-left" href="#">
        <img class="media-object" src="http://placehold.it/64x64" alt="">
    </a>
    <div class="media-body">
        <h4 class="media-heading"><?= $com['auteur']; ?>
            <small><?= $com['date_commentaire']; ?> : <?= $com['note']; ?> / 5</small>
        </h4>
        <?= $com['contenu']; ?>
    </div>
</div>

<?php endforeach; ?>