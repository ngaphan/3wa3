<?php

if (!isset($_GET['id']))
{
	include ROOT.'view/404.php';
	die;
}

$id = (int)$_GET['id'];
$sql = "SELECT * FROM article WHERE id = :idarticle";
$requete = $connexion->prepare($sql);
$requete->bindValue(':idarticle', $id, PDO::PARAM_INT);
$requete->execute();

$article = $requete->fetch(PDO::FETCH_ASSOC);

if (!$article)
{
	include ROOT.'view/404.php';
	die;
}

// Traitement du formulaire


$sql = "SELECT * FROM commentaire WHERE id_article = :idarticle";
$requete = $connexion->prepare($sql);
$requete->bindValue(':idarticle', $id, PDO::PARAM_INT);
$requete->execute();

$commentaires = $requete->fetchAll(PDO::FETCH_ASSOC);