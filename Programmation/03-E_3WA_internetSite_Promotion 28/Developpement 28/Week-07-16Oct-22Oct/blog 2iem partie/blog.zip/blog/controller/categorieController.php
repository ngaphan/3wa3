<?php

$sql = "SELECT * FROM article INNER JOIN categorie ON categorie.id = id_categorie AND id_categorie = :idcat";
$requete = $connexion->prepare($sql);
$requete->bindValue(':idcat', intval($_GET['id']), PDO::PARAM_INT);
$requete->execute();

$categorieArticles = $requete->fetchAll(PDO::FETCH_ASSOC);


$sql = "SELECT nom FROM categorie WHERE id = :idcat";
$requete = $connexion->prepare($sql);
$requete->bindValue(':idcat', intval($_GET['id']), PDO::PARAM_INT);
$requete->execute();

$categorieName = $requete->fetchColumn();