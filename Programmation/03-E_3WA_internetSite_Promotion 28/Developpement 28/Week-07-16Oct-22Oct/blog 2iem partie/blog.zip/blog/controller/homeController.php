<?php

$sql = "SELECT *, categorie.id as idcat FROM article LEFT JOIN categorie ON categorie.id = id_categorie ORDER BY article.id DESC";
$requete = $connexion->prepare($sql);
$requete->execute();

$articles = $requete->fetchAll(PDO::FETCH_ASSOC);