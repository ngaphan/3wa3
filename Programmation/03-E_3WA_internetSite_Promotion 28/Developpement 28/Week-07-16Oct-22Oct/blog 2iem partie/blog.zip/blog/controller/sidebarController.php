<?php

$sql = "SELECT * FROM categorie";
$requete = $connexion->prepare($sql);
$requete->execute();

$categoriesSidebar = $requete->fetchAll(PDO::FETCH_ASSOC);