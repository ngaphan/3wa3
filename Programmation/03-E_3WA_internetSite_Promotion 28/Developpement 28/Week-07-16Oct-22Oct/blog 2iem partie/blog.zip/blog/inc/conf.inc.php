<?php

define ('ROOT', realpath(dirname(__FILE__) . '/../') . '/');

define('ROOT_WEB', substr(ROOT, strlen($_SERVER['DOCUMENT_ROOT'])));

define ('DIR_CSS', ROOT_WEB."view/css/");

define ('DIR_JS', ROOT_WEB."view/js/");


$dsn = 'mysql:host=localhost;dbname=blog;charset=utf8';
$utilisateur = 'root';
$motDePasse = 'troiswa';
$connexion = new PDO( $dsn, $utilisateur, $motDePasse );


function getLittleDescription($texte, $nbchar = 50)
{
	return (strlen($texte) > $nbchar ? substr(substr($texte,0,$nbchar),0,strrpos(substr($texte,0,$nbchar)," "))."..." : $texte);
}