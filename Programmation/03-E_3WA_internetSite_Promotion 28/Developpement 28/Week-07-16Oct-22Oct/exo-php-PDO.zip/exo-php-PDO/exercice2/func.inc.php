<?php

    /**
     * Get the youngest students in an array.
     *
     * @param integer $iSize size of students to get.
     *
     * @return array youngest students.
     */
    function getYoungestStudents($iSize)
    {
        $dsn = 'mysql:host=localhost;dbname=classroom;charset=utf8';
        $utilisateur = 'root';
        $motDePasse = 'troiswa';
        $connexion = new PDO( $dsn, $utilisateur, $motDePasse );

        $requete = $connexion->prepare("SELECT * FROM student ORDER BY birthday desc LIMIT :endlimit");
        $requete->bindValue(':endlimit', $iSize, PDO::PARAM_INT);
        $requete->execute();

        $aStudents = $requete->fetchAll(PDO::FETCH_ASSOC);

        return $aStudents;
    }