<?php

/**
 * Display message to screen.
 *
 * @param string $sTextToPrint
 *            text to print.
 * @param bool $bSuccess success or error.
 */
function displayMessage($sTextToPrint, $bSuccess)
{
    if ($bSuccess):
        ?>
        <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <strong>Success!</strong> <?= $sTextToPrint; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <strong>Warning!</strong> <?= $sTextToPrint; ?>
        </div>
    <?php endif;
}

/**
 * Add a new student to the database.
 *
 * @param string $sName student name.
 * @param date $dBirthday birthday.
 * @return bool true if success, false otherwise.
 */
function addStudent($sFirstname, $sLastname, $sAddress, $sGender, $dBirthday)
{
    // name cannot be empty, and should be at least 3 characters
    if ('' === $sFirstname || strlen($sFirstname) < 3) {
        displayMessage('name cannot be empty, and should be at least 3 characters!', false);
        return false;
    }

    // database connexion
    $dsn = 'mysql:host=localhost;dbname=classroom;charset=utf8';
    $utilisateur = 'root';
    $motDePasse = 'troiswa';
    $connexion = new PDO( $dsn, $utilisateur, $motDePasse );


    $requete = $connexion->prepare("INSERT INTO student (firstname, lastname, birthday, address, gender) VALUES (:firstname, :lastname, :birthday, :address, :gender)");
    $requete->bindValue(':firstname', $sFirstname, PDO::PARAM_STR);
    $requete->bindValue(':lastname', $sLastname, PDO::PARAM_STR);
    $requete->bindValue(':address', $sAddress, PDO::PARAM_STR);
    $requete->bindValue(':birthday', $dBirthday, PDO::PARAM_STR);
    $requete->bindValue(':gender', $sGender, PDO::PARAM_BOOL);
    $success = $requete->execute();

    // something went wrong in the query
    if (false === $success) {
        displayMessage('something went wrong in the query', false);
        return false;
    }

    // otherwise : success
    return true;
}