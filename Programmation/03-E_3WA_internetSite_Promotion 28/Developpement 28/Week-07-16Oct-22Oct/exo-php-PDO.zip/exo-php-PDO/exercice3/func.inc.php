<?php

function getConnexion()
{
    $dsn = 'mysql:host=localhost;dbname=classroom;charset=utf8';
    $utilisateur = 'root';
    $motDePasse = 'troiswa';
    $connexion = new PDO( $dsn, $utilisateur, $motDePasse );

    return $connexion;
}

function getCities($iIndexFrom, $iSize)
{
    $connexion = getConnexion();

    $requete = $connexion->prepare("SELECT * FROM student ORDER BY id asc LIMIT :index , :size");
    $requete->bindValue(':index', (int) $iIndexFrom, PDO::PARAM_INT);
    $requete->bindValue(':size', (int) $iSize, PDO::PARAM_INT);
    $requete->execute();

    $aStudents = $requete->fetchAll(PDO::FETCH_ASSOC);

    return $aStudents;
}



function nbTotalStudent()
{
    $connexion = getConnexion();

    $requete = $connexion->prepare("SELECT COUNT(*) AS total FROM student");
    $requete->execute();

    $nbStudents = $requete->fetchColumn();
    
    return $nbStudents;
}


function displayPagination($iFrom)
{
    $iMaxPage = intval(ceil(NB_STUDENT / MAX_PER_PAGE));
    $iCurrentPage = intval(floor($iFrom / MAX_PER_PAGE) + 1);
    ?>
    <ul class="pagination">
        <?php
            for($i = 1; $i <= $iMaxPage; $i++)
            {
                if ($i == $iCurrentPage)
                {
                    echo '<li class="active"><a href="?page='.$i.'">'.$i.'</a></li>';
                }
                else
                {
                    echo '<li><a href="?page='.$i.'">'.$i.'</a></li>';
                }
            }
        ?>
    </ul>
<?php
}