<?php

$dsn = 'mysql:host=localhost;dbname=blog;charset=utf8';
$utilisateur = 'root';
$motDePasse = 'troiswa';
$connexion = new PDO( $dsn, $utilisateur, $motDePasse );

$requete = $connexion->prepare("SELECT * FROM article ORDER BY id DESC");
$requete->execute();

$articles = $requete->fetchAll(PDO::FETCH_ASSOC);