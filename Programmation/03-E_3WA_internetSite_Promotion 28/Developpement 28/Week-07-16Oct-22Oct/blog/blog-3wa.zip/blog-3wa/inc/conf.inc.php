<?php

define ('ROOT', realpath(dirname(__FILE__) . '/../') . '/');

define('ROOT_WEB', substr(ROOT, strlen($_SERVER['DOCUMENT_ROOT'])));

define ('DIR_CSS', ROOT_WEB."view/css/");

define ('DIR_JS', ROOT_WEB."view/js/");