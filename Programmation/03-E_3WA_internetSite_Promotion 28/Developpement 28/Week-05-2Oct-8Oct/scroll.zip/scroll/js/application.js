$(document).ready(function()
{
    var id = false;
    var scrolled_href = false;
    var scrollTop;
    var buttonTop = $('#top');
    var navA = $('nav').find('a');

    navA.click(function(e)
    {
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $($(this).attr('href')).offset().top + 1
        })
        hash($(this).attr('href'));
    });


    buttonTop.click(function()
        {
            scrollTop = 0;
            id = false;
            $("html, body").animate({scrollTop: 0}, 1000);
        })

    $(window).scroll(function(){
        scrollTop = $(this).scrollTop();

        if (scrollTop > 1000)
        {
            buttonTop.fadeIn();
        }
        else
        {
            buttonTop.fadeOut();
        }
  

        navA.each(function()
        {
            if (scrollTop >= $($(this).attr('href')).offset().top)
            {
                scrolled_href = $(this).attr('href');
            }
        })
        


        if (scrolled_href != id)
        {
            id = scrolled_href;
            navA.removeClass('active');
            $('nav').find('a[href="'+ id +'"]').addClass('active');
        }
    });

    function hash(h)
    {
        if (history.pushState)
        {
            history.pushState(null, null, h);
        }
        else
        {
            location.hash = h;
        }
    }
});
