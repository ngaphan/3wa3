$(document).ready(function()
{
	var ul = $('#slider').children('ul');
	var li = $('#slider').children('ul').children('li');
	var nbLi = 1;
	var nbLiTotal = li.length;
	var tailleOneLi = li.width();
	var tailleTotalLi = li.width() * (nbLiTotal - 1);
	// Intervalle
	var oInterval;
	
	$('#plus').click(function(event)
	{
		// stop le comportement par défaut du lien
		event.preventDefault();

		if (nbLi < nbLiTotal)
		{
			// Stop l'animation en cours. voir la documentation sur jquery
			ul.stop(true, true).animate({
				left : '-='+tailleOneLi
			});

			nbLi++;
		}
		else
		{
			ul.stop(true, true).animate({
				left : '0'
			});

			nbLi = 1;
		}

	});

	$('#moins').click(function(event)
	{
		// stop le comportement par défaut du lien
		event.preventDefault();

		if (nbLi == 1)
		{
			ul.stop(true, true).animate({
				left : (tailleTotalLi * -1)
			});

			nbLi = nbLiTotal;
		}
		else
		{
			ul.stop(true, true).animate({
				left : '+='+tailleOneLi
			});

			nbLi--;
		}
	});

	$('#displayOptions').click(function()
	{
		$('#options').fadeIn();
	});

	function go()
	{
		$('#plus').trigger('click')
	};


	$('#startAuto').click(function () {
	    clearInterval(oInterval);
	    go();
	    oInterval = setInterval(go, 2000);
	});

	$('#stopAuto').click(function () {
	    clearInterval(oInterval);
	});
});