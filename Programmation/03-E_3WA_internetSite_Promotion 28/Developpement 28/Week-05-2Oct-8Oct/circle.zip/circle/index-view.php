<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Cercles de compétences</title>
</head>
<body>

	<style type="text/css">
		div
		{
			text-align: center;
		}
	</style>

	<?php
		foreach ($competences as $value) {
			echo '<div><input data-readOnly=true value="'.$value['rate'].'" type="text" data-fgColor="'.$value['color'].'" class="dial"><p>'.$value['label'].'</p></div>';
		}
	?>

	<script src="js/jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src="js/jquery.knob.js"></script>
	<script type="text/javascript" src="js/application.js"></script>
</body>
</html>