$(document).ready(function()
{
	$(".dial").knob();

	$(".dial").each(function()
	{
		$(this).animate({
			rate: parseInt($(this).val())
		},
		{
			duration: 2000,
			step: function()
			{
				$(this).val(this.rate).trigger("change"); 
			}
		}); 
	});
	

});