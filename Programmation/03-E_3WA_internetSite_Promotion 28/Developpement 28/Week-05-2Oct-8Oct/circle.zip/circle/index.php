<?php


$competences = [
	['color' => '#e74c3c', 'rate' => 80, 'label' => 'js'],
	['color' => '#2980b9', 'rate' => 50, 'label' => 'php'],
];

include 'index-view.php';