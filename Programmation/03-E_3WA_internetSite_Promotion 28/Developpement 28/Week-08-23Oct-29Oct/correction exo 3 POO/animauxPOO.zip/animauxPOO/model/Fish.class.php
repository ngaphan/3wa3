<?php

    class Fish extends Animal
    {
    	public function swim()
    	{
    		echo 'I can swim';
    	}
    }