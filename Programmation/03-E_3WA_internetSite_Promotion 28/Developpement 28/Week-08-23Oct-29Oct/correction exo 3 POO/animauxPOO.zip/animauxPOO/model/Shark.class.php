<?php

    class Shark extends Fish
    {
        /**
         * @var int strength
         */
        private $iStrength;

        public function __construct($name, $speed, $weight, $hp, $strength)
        {
            parent::__construct($name, $speed, $weight, $hp);
            $this->iStrength = $strength;
        }

        public function attack($oAnimal)
        {
            $oAnimal->reduceHP($this->iStrength);
        }

        public function getStrength()
        {
            return $this->iStrength;
        }

        public function setStrength($iStrength)
        {
            $this->iStrength = $iStrength;
        }
    }