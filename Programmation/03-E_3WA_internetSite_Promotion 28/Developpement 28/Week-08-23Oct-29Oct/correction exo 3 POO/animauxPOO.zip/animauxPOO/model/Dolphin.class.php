<?php

    class Dolphin extends Fish
    {

    }