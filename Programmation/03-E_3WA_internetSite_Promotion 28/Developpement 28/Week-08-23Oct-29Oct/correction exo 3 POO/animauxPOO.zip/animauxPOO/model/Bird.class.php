<?php

    class Bird extends Animal
    {
    	public function fly()
    	{
    		echo 'I can fly';
    	}
    }