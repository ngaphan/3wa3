<?php

    class Whale extends Fish
    {
        public function growUp()
        {
            $this->setSpeed($this->getSpeed() * 1.02);
            $this->setWeight($this->getWeight() * 1.5);
        }


    }