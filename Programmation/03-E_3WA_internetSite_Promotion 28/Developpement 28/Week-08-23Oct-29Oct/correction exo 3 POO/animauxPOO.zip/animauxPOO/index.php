<?php

/*
include 'model/Animal.class.php';
include 'model/Bird.class.php';
include 'model/Fish.class.php';
include 'model/Dolphin.class.php';
include 'model/Whale.class.php';
include 'model/Shark.class.php';
include 'model/Eagle.class.php';
*/

function loadclass($class) {
    include 'model/' . $class . '.class.php';
}

spl_autoload_register('loadclass');


$willy = new Whale("Willy", 70, 1000, 100);
echo $willy.'<br>';

$requin = new Shark("Sharky", 150, 300, 100, 50);
$requin->attack($willy);
echo $willy->getHP();