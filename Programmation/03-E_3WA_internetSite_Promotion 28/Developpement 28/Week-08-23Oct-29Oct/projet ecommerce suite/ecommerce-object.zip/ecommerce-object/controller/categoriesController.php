<?php

$CategorieManager = new CategorieManager($DB);
$categories = $CategorieManager->getCategories();