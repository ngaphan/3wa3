<?php include ROOT.'controller/sidebarController.php'; ?>

<div class="col-md-3">
    <p class="lead">Shop Name</p>
    <div class="list-group">
        <a href="#" class="list-group-item">Category 1</a>
        <a href="#" class="list-group-item">Category 2</a>
        <a href="#" class="list-group-item">Category 3</a>
    </div>
</div>