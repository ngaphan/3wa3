<?php

$cinemas =
[
	'cine-1' => 'UGC Opéra',
	'cine-2' => 'Gaumont Parnasse',
	'cine-3' => 'MK2 Bibliothèque',
	'cine-4' => 'UGC Ciné-cité Bercy'
];

$covers =
[
	'1.jpg',
	'2.jpg',
	'3.jpg',
	'4.jpg',
	'5.jpg',
	'6.jpg',
	'7.jpg',
	'8.jpg'
];

$movies =
[
	'movie-1' => [ 'title' => 'X-Men: Days of Future Past',           'duration' => 124, 'cover' => 0, 'description' => 'lorem ipsum' ],
	'movie-2' => [ 'title' => 'Grace de Monaco',                      'duration' => 96,  'cover' => 1, 'description' => 'lorem ipsum' ],
	'movie-3' => [ 'title' => 'Captain America 2',                    'duration' => 136, 'cover' => 2, 'description' => 'lorem ipsum' ],
	'movie-4' => [ 'title' => 'Les yeux jaunes des crocodiles',       'duration' => 121, 'cover' => 3, 'description' => 'lorem ipsum' ],
	'movie-5' => [ 'title' => 'Rio 2',                                'duration' => 88,  'cover' => 4, 'description' => 'lorem ipsum' ],
	'movie-6' => [ 'title' => 'Spiderman',                            'duration' => 145, 'cover' => 5, 'description' => 'lorem ipsum' ],
	'movie-7' => [ 'title' => "Qu'est ce qu'on a fait au bon Dieu ?", 'duration' => 114, 'cover' => 6, 'description' => 'lorem ipsum' ],
	'movie-8' => [ 'title' => 'Grand Budapest Hotel',                 'duration' => 128, 'cover' => 7, 'description' => 'lorem ipsum' ]
];

$rooms =
[
	'cine-1' => [ 'movie-5', 'movie-1', 'movie-6', 'movie-8' ],
	'cine-2' => [ 'movie-3', 'movie-7', 'movie-4', 'movie-2' ],
	'cine-3' => [ 'movie-1', 'movie-2', 'movie-5', 'movie-4' ],
	'cine-4' => [ 'movie-8', 'movie-7', 'movie-5', 'movie-2', 'movie-3', 'movie-6', 'movie-4', 'movie-1' ]
];