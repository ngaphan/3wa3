<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>JavaScript</title>
    <link rel="stylesheet" type="text/css" href="css/normalize.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans">
    <link rel="stylesheet" type="text/css" href="css/movies.css">
    <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
</head>
<body>
    <h1>Les films dans le cinémas <?= $cinemas[$_POST['cinema']] ?></h1>
    <ul class="movie-list">
        <?php foreach($foundMovies as $key => $movie): ?>
            <li>
                <a title="<?= $movie['title'] ?>" class="fancybox" href="images/<?= $covers[$movie['cover']] ?>" data-fancybox-group="gallery">
                    <img src="images/<?= $covers[$movie['cover']] ?>">
                </a>
                <p>
                    <strong><?= $movie['title'] ?></strong> -
                    <em><?= intval($movie['duration'] / 60) ?>h<?= intval($movie['duration'] % 60) ?></em>
                </p>
                <a href="movie.php?film=<?= $key ?>">En savoir plus</a>
            </li>
        <?php endforeach; ?>
    </ul>
    <a href="index.php">Retour home</a>

    <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.fancybox').fancybox();
        });
    </script>
</body>
</html>