<?php

// Fichiers communs.

include 'data.php';


$foundMovies = array();

foreach($rooms[$_POST['cinema']] as $room)
{
	$foundMovies[$room] = $movies[$room];
}


// Sélection du template à afficher.

include 'search-results.php';