<?php

include 'data.php';


$foundMovies = array_filter($movies, function($movie)
{
	return $movie['duration'] <= $_POST['duration'];
});


include 'search-results-duration.php';