<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>PHP</title>
    <link rel="stylesheet" type="text/css" href="css/normalize.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans">
    <link rel="stylesheet" type="text/css" href="css/movies.css">
    <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
</head>
<body>
    <h1>Les films</h1>

    <ul class="movie-list">
        <?php foreach($movies as $key => $movie): ?>
            <li>
                <a title="<?= $movie['title'] ?>" class="fancybox" href="images/<?= $covers[$movie['cover']] ?>" data-fancybox-group="gallery">
                    <img src="images/<?= $covers[$movie['cover']] ?>">
                </a>
                <p>
                    <strong><?= $movie['title'] ?></strong> -
                    <em><?= intval($movie['duration'] / 60) ?>h<?= intval($movie['duration'] % 60) ?></em>
                </p>
                <a href="movie.php?film=<?= $key ?>">En savoir plus</a>
            </li>
        <?php endforeach; ?>
    </ul>

    <hr>
    <h2>Recherche par cinéma</h2>
    <form class="standard-form" method="POST" action="search-movies.php">
        <ul>
            <li>
                <label for="cinema">Cinéma :</label>
                <select id="cinema" name="cinema">
                    <?php foreach($cinemas as $key => $cinema): ?>
                        <option value="<?= $key ?>"><?= $cinema ?></option>
                    <?php endforeach; ?>
                </select>
            </li>
            <li>
                <input type="submit" value="Rechercher">
            </li>
        </ul>
    </form>

    <hr>
    <h2>Recherche par durée maximum d'un film</h2>
    <form class="standard-form" method="POST" action="search-duration.php">
        <ul>
            <li>
                <label for="duration">Durée en minutes :</label>
                <input type="text" id="duration" name="duration">
            </li>
            <li>
                <input type="submit" value="Rechercher">
            </li>
        </ul>
    </form>

    <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.fancybox.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.fancybox').fancybox();
        });
    </script>
</body>
</html>