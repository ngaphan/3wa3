<?php

// Fichiers communs.

include 'data.php';




// Sélection du template à afficher.

include 'index-view.php';