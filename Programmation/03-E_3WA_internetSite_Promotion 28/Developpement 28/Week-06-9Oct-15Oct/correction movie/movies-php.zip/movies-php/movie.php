<?php

include 'data.php';

if (!isset($_GET['film']) || empty($_GET['film'])  || !array_key_exists($_GET['film'], $movies))
{
	header('Location:index.php');
}

$keyFilm = $_GET['film'];
$film = $movies[$keyFilm];

function cle_suivante($arr, $key)
{
	$nextKey = null;
	$keys = array_keys($arr);
	$keyIndexes = array_flip($keys);

	if (isset($keys[$keyIndexes[$key]+1])) {
		$nextKey = $keys[$keyIndexes[$key]+1];
	}

	return $nextKey;
}

function cle_precedante($arr, $key)
{
	$prevKey = null;
	$keys = array_keys($arr);
	$keyIndexes = array_flip($keys);

	if (isset($keys[$keyIndexes[$key]-1])) {
		$prevKey = $keys[$keyIndexes[$key]-1];
	}

	return $prevKey;
}

$prev = cle_precedante($movies, $keyFilm);
$next = cle_suivante($movies, $keyFilm);


?>

<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

	<img src="images/<?= $covers[$film['cover']] ?>">
	<p>
		<strong><?= $film['title'] ?></strong> -
		<em><?= intval($film['duration'] / 60) ?>h<?= intval($film['duration'] % 60) ?></em>
	</p>
	<p><?= $film['description'] ?></p>

	<?php
		if ($prev)
		{
			echo '<a href="movie.php?film='. $prev .'">Film precedent</a><br>';
		}

		if ($next)
		{
			echo '<a href="movie.php?film='. $next .'">Film suivant</a><br>';
		}
	?>

	<a href="index.php">Retour home</a>

</body>
</html>