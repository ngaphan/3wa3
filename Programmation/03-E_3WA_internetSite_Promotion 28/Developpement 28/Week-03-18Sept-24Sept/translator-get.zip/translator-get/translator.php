<?php

// Le code principal de l'application se trouve dans une fonction.
function translate($word, $direction)
{
    // Le dictionnaire du traducteur.
    $dictionary =
    [
        'cat'    => 'chat',
        'dog'    => 'chien',
        'monkey' => 'singe',
        'sea'    => 'mer',
        'sun'    => 'soleil'
    ];


    // Traduction du mot en -> fr ou fr -> en.
    switch($direction)
    {
        case 'toFrench':
        /*
         * Le mot spécifié est en anglais, on veut traduire vers le français.
         *
         * Il s'agit donc d'un indice dans le dictionnaire.
         * Est-ce que ce mot existe en tant qu'indice dans le dictionnaire ?
         */
        if(isset($dictionary[$word]))
        {
            // Oui, récupération de la valeur, de la traduction en français.
            $translatedWord = $dictionary[$word];

            $message = "Le mot '$word' se traduit par '$translatedWord'.";
        }
        else
        {
            // Non, cet indice n'existe pas.
            $message = "Je ne connais pas le mot '$word'.";
        }
        break;

        case 'toEnglish':
        /*
         * Le mot spécifié est en français, on veut traduire vers l'anglais.
         *
         * Il s'agit donc d'une valeur dans le dictionnaire.
         * Est-ce que ce mot existe en tant que valeur dans le dictionnaire ?
         */
        if(in_array($word, $dictionary) == true)
        {
            // Oui, récupération de l'indice, de la traduction en anglais.
            $translatedWord = array_search($word, $dictionary);

            $message = "Le mot '$word' se traduit par '$translatedWord'.";
        }
        else
        {
            // Non, cette valeur n'existe pas.
            $message = "Je ne connais pas le mot '$word'.";
        }
        break;

        default:
            $message = "Je ne sais traduire qu'en français et en anglais !";
    }

    return $message;
}


/*
 * Récupération des informations dans la query string.
 *
 *
 * PHP fournit une variable $_GET qui permet de lire les données de la query string :
 *
 * Exemple d'URL : http://www.site.fr/exemple.php?nom=machin&age=25
 *
 * $_GET['nom'] vaudra la chaîne 'machin'
 * $_GET['age'] vaudra le nombre 25
 */

$direction = 'toFrench';
if(array_key_exists('direction', $_GET) == true)
{
    // Une direction a été spécifiée dans l'URL, récupération de la valeur.
    $direction = $_GET['direction'];
}

if(isset($_GET['word']))
{
    // Récupération du mot spécifié dans l'URL.
    $word = strtolower($_GET['word']);

    // Traduction du mot dans la direction spécifiée.
    $result = translate($word, $direction);
}
else
{
    $result = "Vous n'avez indiqué aucun mot !";
}

// Sélection du template affichant la variable $result.
include 'translator-view.php';