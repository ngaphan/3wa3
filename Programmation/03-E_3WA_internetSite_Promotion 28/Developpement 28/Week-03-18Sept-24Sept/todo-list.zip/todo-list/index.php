<?php

// --------------------------------------------------------------------------------------
// DEPENDANCES
// --------------------------------------------------------------------------------------


include 'utilities.php';


// --------------------------------------------------------------------------------------
// CODE PRINCIPAL
// --------------------------------------------------------------------------------------

// Initialisation des variables utilisées dans le template.
$tasks = loadTasks();
$title = 'PHP - TodoList';

/*
 * Création d'une cinquième colonne indiquant si la tâche est en retard ou pas.
 *
 * Le tableau de tâches possèdes trois colonne à la base :
 * 1. Titre
 * 2. Contenu
 * 3. Date de la tâche
 * 4. Priorité
 *
 * Il faut parcourir tout le tableau de tâches et comparer la date d'une tâche avec la
 * date du jour pour obtenir le résultat.
 */

// Récupération de la date du jour.
$now = date_create();

/*
 * Parcours du tableau de tâches.
 *
 * /!\ Il est interdit de faire un foreach d'un tableau que l'on modifie en même temps !
 *
 */
for($index = 0; $index < count($tasks); $index++)
{
    // Récupération de la date de la tâche.
    $dueDate = date_create($tasks[$index][2]);

    // Calcul de la différence entre les deux dates.
    $interval = date_diff($now, $dueDate);

    // Est-ce que l'interval est négatif ?
    if($interval->invert == 1)
    {
        // Oui, la tâche est en retard.
        $tasks[$index][4] = true;
    }
    else
    {
        // Non, la tâche n'est pas en retard.
        $tasks[$index][4] = false;
    }
}


// --------------------------------------------------------------------------------------
// TEMPLATE
// --------------------------------------------------------------------------------------

// Chargement du template.
include 'index-view.php';