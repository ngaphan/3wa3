<?php

// --------------------------------------------------------------------------------------
// DEPENDANCES
// --------------------------------------------------------------------------------------

include 'utilities.php';



// --------------------------------------------------------------------------------------
// CODE PRINCIPAL
// --------------------------------------------------------------------------------------

// Si l'utilisateur n'a pas saisi de titre à la tâche alors on ne l'ajoute pas.
if(isset($_POST['title']) && empty($_POST['title']) == false) // ou if($_POST['title'] != '')
{

    // Création du tableau contenant la tâche.
    $taskData =
	[
		$_POST['title'],
		$_POST['contents'],
		$_POST['day'].'-'.$_POST['month'].'-'.$_POST['year'],
		$_POST['priority']
	];

	// Sauvegarde du tableau dans le fichier CSV.
	saveTask($taskData);
}

/*
 * Redirection vers la page d'accueil.
 *
 * Il est impératif de rediriger en HTTP GET après l'envoi d'un formulaire en HTTP POST.
 * Cela s'appelle le Post-Redirect-Get ou PRG - Lire la page Wikipédia à ce sujet.
 */
header('Location: index.php');