<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title><?php echo  $title ?></title>
    <link rel="stylesheet" type="text/css" href="todolist.css">
</head>
<body>
	<section>
		<h1>Gestionnaire de tâches</h1>

		<?php if(empty($tasks) == false): ?>
			<!-- Formulaire listant toutes les tâches existantes avec possibilité de suppression. -->
			<form class="standard-form" action="remove.php" method="POST">
				<ul class="task-list">
					<?php foreach($tasks as $index => $taskData): ?>
						<li>
							<input id="task-<?php echo $index ?>" type="checkbox" name="indexes[]" value="<?php echo $index ?>">
							<label for="task-<?php echo $index ?>" class="<?php echo $taskData[3] ?> ">
								<?php echo $taskData[0] ?>
                                <?php if($taskData[4] == true): ?>
                                    <strong>- en retard</strong>
                                <?php endif ?>
							</label>
							<p><?php echo $taskData[1] ?></p>
						</li>
					<?php endforeach ?>
					<li>
						<input type="submit" value="Supprimer" title="Supprimer les tâches cochées">
					</li>
				</ul>
			</form>
			<hr>
		<?php endif ?>

		<!-- Formulaire d'ajout de tâche -->
		<form class="standard-form label-left" action="add.php" method="POST">
			<fieldset>
				<legend>Informations sur la tâche</legend>
				<ul>
					<li>
						<label for="title">Titre :</label>
						<input id="title" name="title" type="text">
					</li>
					<li>
						<label for="contents">Tâche :</label>
						<textarea id="contents" name="contents" rows="5"></textarea>
					</li>
					<li>
						<label for="day">Date de fin :</label>
						<select id="day" name="day">
							<?php for($day = 1; $day <= 31; $day++): ?>
								<option value="<?php echo $day ?>"><?php echo $day ?></option>
							<?php endfor ?>
						</select>
						<span>/</span>
						<select name="month">
							<option value="1">Janvier</option>
							<option value="2">Février</option>
							<option value="3">Mars</option>
							<option value="4">Avril</option>
							<option value="5">Mai</option>
							<option value="6">Juin</option>
							<option value="7">Juillet</option>
							<option value="8">Août</option>
							<option value="9">Septembre</option>
							<option value="10">Octobre</option>
							<option value="11">Novembre</option>
							<option value="12">Décembre</option>
						</select>
						<span>/</span>
						<select name="year">
							<?php for($year = date('Y'); $year < date('Y') + 10; $year++): ?>
								<option value="<?php echo $year ?>"><?php echo $year ?></option>
							<?php endfor ?>
						</select>
					</li>
					<li>
						<label for="priority">Priorité :</label>
						<select id="priority" name="priority">
							<option value="priority-low">Basse</option>
							<option value="priority-normal" selected>Normale</option>
							<option value="priority-high">Haute</option>
						</select>
					</li>
					<li>
						<input id="submit" type="submit" value="Ajouter" title="Ajouter une nouvelle tâche">
					</li>
				</ul>
			</fieldset>
		</form>
	</section>
</body>
</html>