$(document).ready(function() {

    // console.log($('.page-header').text().toLowerCase());

    //console.log($('.plan-name'));
    
    //console.log($('.plan-name').text());

    //$('.plan-name').text("hello");

    //console.log($('.plan').not('.featured'));

    //console.log($('.plan').filter(':odd'));

    //console.log($('.plan').filter(':even'));

    //console.log($('.plan').first());

    //console.log($('.plan').last());

    //$('.plan').filter(".featured").children('.plan-name').text('hello');

    
    var message = $("<span>lorem ipsum</span>");
    //$('.plan-action').before(message)
    $('.plan-action').after(message);

    $('.plan').on('click', '.btn', function(event)
    {
        event.preventDefault();
        //$(this).closest('.plan').addClass('featured');

        var planUl = $(this).closest('.plan');
        deselect(planUl.parent().index());
        planUl.toggleClass('featured');
        $(this).parent('li').next('span').remove();

        var price = planUl.children('.plan-price').children('strong').text();
        var message = $("<p class='final-price'>Vous avez selectionné l'offre à "+price+"</p>");
        message.css('opacity', '0');
        $('h1').after(message);
        message.animate({'opacity' : '1'});
    });


    $('.btn-warning').on('click', function()
    {
        deselect();
    });

    $('.quantity').on('keyup', function()
    {
        var qty = +$(this).val();
        var price = +$(this).closest('.plan').children('.plan-price').children('strong').text().replace('$', '');
        total = price * qty;
        var message = $("<p class='result'>Votre offre vous coûtera : "+total+"</p>");
        $(this).closest('.plan').find('.result').remove();
        $(this).after(message);
    })

    function deselect(index)
    {
        // S'il existe un index (index étant le numéro du ul)
        // On déselectionner tous les autres sauf le ul courant
        if (typeof index !== 'undefined')
        {
            $('.plan').not(":eq("+index+")").removeClass('featured');
        }
        else
        {
            $('.plan').removeClass('featured');
        }
        $('.final-price').remove();
    }

});